﻿using System.ComponentModel.DataAnnotations;

namespace Management.Models
{
    public class Book
    {
        [Key]
        public Guid ISBN { get; set; }
        public string BookName { get; set; }
        public string AutherName { get; set; }
        public int Price { get; set; }
        public int Quntity { get; set; }

    }
}
