﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Management.Models;

namespace Management.Data
{
    public class ManagementContext : DbContext
    {
        public ManagementContext (DbContextOptions<ManagementContext> options)
            : base(options)
        {
        }

        public DbSet<Management.Models.Admin> Admin { get; set; } = default!;
        public DbSet<Management.Models.Book> Book { get; set; } = default!;
    }
}
