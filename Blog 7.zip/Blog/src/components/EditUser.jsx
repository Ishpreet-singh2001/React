import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import { createURL } from "../config";

const EditUser = () => {
  //const { id } = useParams();
  const navigate = useNavigate();
  const [id,setId]=useState();
  const [fname, setFname] = useState("");
  const [lname, setLname] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const[password,setPassword]=useState();
  const token = sessionStorage["token"];
  const onSave = () => {
    const token = sessionStorage["token"];
    const data={
      userId:id,
      firstName:fname,
      lastName:lname,
      email:email,
      password:password,
      phone:phone,
      UserType:"User"
  }
    if (!token) {
      navigate("/");
      return;
    }
    axios
      .put(`https://localhost:7289/api/Users/${id}`, data, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        const result = response.data;
        
        if (response.status===204) {
          const data = result["data"];
          toast.success("successfully update user");
          navigate("/profile  ");
        } else {
          toast.error("error while update user");
        }
      });
  };

  const loadProfile = () => {
    const token = sessionStorage["token"];

    axios
      .get(`https://localhost:7289/api/Users/user`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        const result = response.data;
        if (response.status === 200){
          const data = result;
          setId(data.userId);
          setFname(data.firstName);
          setEmail(data.email);
          setPassword(data.password);
          setLname(data.lastName);
          setPhone(data.phone);
        } else {
          console.log("error");
        }
      });
  };
  useEffect(() => {
    loadProfile();
  }, []);

  return (
    <div>
      <div className="row">
        <div className="col"></div>
        <div
          className="col"
          style={{
            boxShadow: "10px 10px 5px lightgrey",
            border: "1px solid black",
            borderRadius: 10,
            marginTop: 50
          }}
        >
          <h2 className="title" style={{fontFamily: 'Times New Roman'}}>Edit Profile</h2>

          <div className="form-group">
            <label htmlFor="">First Name :</label>
            <input
              onChange={(e) => setFname(e.target.value)}
              value={fname}
              type="text"
              className="form-control"
            />
          </div>
          <div className="form-group">
            <label htmlFor="">Last Name :</label>
            <input
              onChange={(e) => setLname(e.target.value)}
              value={lname}
              type="text"
              className="form-control"
            />
          </div>
          <div className="form-group">
            <label htmlFor="">Mobile Number :</label>
            <input
              onChange={(e) => setPhone(e.target.value)}
              value={phone}
              type="number"
              className="form-control"
            />
          </div>
          <div className="form-group">
            <label htmlFor="">Email :</label>
            <input
              onChange={(e) => setEmail(e.target.value)}
              value={email}
              type="email"
              className="form-control"
            />
          </div>
          <div className="form-group">
            <label htmlFor="">Password :</label>
            <input
              onChange={(e) => setPassword(e.target.value)}
              value={password}
              type="password"
              className="form-control"
            />
          </div>
          <div
            className="form-group"
            style={{ marginTop: 20, marginBottom: 20 }}
          >
            <button
              style={{ marginLeft: 80 }}
              onClick={() => onSave(id)}
              className="btn btn-success"
            >
              Save
            </button>
            <Link
              style={{ marginLeft: 40 }}
              to={"/profile"}
              className="btn btn-warning"
            >
              Cancel
            </Link>
          </div>
        </div>
        <div className="col"></div>
      </div>
    </div>
  );
};
export default EditUser;
