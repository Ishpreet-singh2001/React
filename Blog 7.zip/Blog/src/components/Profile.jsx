import { useEffect, useState } from "react";
import { createURL } from "../config";
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios'
import { toast } from "react-toastify";
import Personimg from '../image/person.jpg'
const Profile = () => {
    const [items, setItems] = useState();
    const navigate = useNavigate();

    const loadProfile = () => {
        const url = createURL("api/Users/user");

        const token = sessionStorage["token"];
        if (!token) {
            navigate("/login");
            return;
        }
        axios.get(url, {
            headers: {
                "Authorization": `Bearer ${token}`,
            },
        })
            .then((response) => {
                const result = response.data;
                if (response.status === 200) {
                    const data = result;
                    sessionStorage["firstName"] = data.firstName;
                    sessionStorage["lastName"] = data.lastName;
                    setItems(data);
                   
                } else {
                    alert("error while loading your Profile");
                    navigate("/");
                }
                
            })
            .catch((error) => {
                console.log(`error: `, error)
            });
    };
    
    useEffect(() => {
        loadProfile();
    }, []);

    return (
        <div>

            <div className="row">
                <div className="col"></div>
                <div className="col" style={{ boxShadow: "10px 10px 5px lightgrey", border: "1px solid black", borderRadius: 10, marginTop:45 }}>
                    <h2 className="title mb-3">Profile</h2>
                    <div className="text-center">
                    {items && <img style={{objectFit:"cover",objectPosition:"center",borderRadius:"50%"}} src={Personimg} width="130" height="130" alt="profile image" />}
                    </div>
                    <div className="mt-3"><strong>Name: </strong><span>{items && items.firstName + " " + items.lastName}</span></div>

                    <div className="mt-3"><strong>Email: </strong><span>{items && items.email}</span></div>
                    <div className="mt-3"><strong>Phone: </strong><span>{items && items.phone}</span></div>

                    <Link style={{ marginTop: 40, marginBottom: 40, marginLeft: 130 }} className="btn btn-success" to={`edit-user/${items && items.id}`}>Edit Profile</Link>
                </div>
                <div className="col"></div>
            </div>
        </div>
    )
}
export default Profile;