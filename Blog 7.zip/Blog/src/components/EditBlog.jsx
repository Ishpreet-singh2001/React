import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import { createURL } from "../config";

const EditBlog = () => {
    
    const { id } = useParams();
    console.log(id);
    const [title, setTittle] = useState("");
    const [details, setDetails] = useState("");
    const [date,setDate]=useState();
    const navigate = useNavigate();
    const token=sessionStorage["token"];
    const loadBlogs = () => {
        const url = createURL(`api/Blogs/${id}`);
        if (!token) {
            navigate("/");
            return;
        }
        axios.get(url, {
            headers: {
                "Authorization": `Bearer ${token}`,
            },
        })
            .then((response) => {
                const result = response.data;
                console.log(response)
                if (response.status==200) {
                    const data = result;
                    console.log(data);
                    setTittle(data.title);
                    setDetails(data.details);
                    console.log(data.createdDate);
                    setDate(data.createdDate);
                } else {
                    alert("error while loading your blogs");
                    //navigate("/")
                }
            })
            .catch((error) => {
                console.log(`error: `, error)
            });
    };

    useEffect(() => {
        loadBlogs();
    }, []);
    
    const onSave = () => {
        const data={
            title:title, 
            details:details, 
            idblog:id,
            createdDate:new Date()
        }
        const url = createURL(`api/Blogs/${id}`);
        const token = sessionStorage["token"];
        if (!token) {
            navigate("/");  
            return;
        }
        axios.put(url, data, {
            headers: {
                "Authorization": `Bearer ${token}`,
            },
        })
            .then((response) => {
                // const result = response.data;
                if (response.status==204) {
                    // const data = result["data"];
                    toast.success("successfully update blog");
                    navigate('/my-blog')
                } else {
                    toast.error("error while update blog")
                }
            })

    }
    return (
        <div>
            <div className="row">
                <div className="col"></div>
                <div className="col" style={{ boxShadow: "10px 10px 5px lightgrey", border: "1px solid black", borderRadius: 10, marginTop: 20 }}>
                    <h2 className="title" style={{fontFamily: 'Times New Roman'}}>Edit Blog</h2>
                    <div className="form-group">
                        <label htmlFor="">Title :</label>
                        <input onChange={(e) => setTittle(e.target.value)} value={title} type="text" className="form-control" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">Content :</label>
                        <textarea onChange={(e) => setDetails(e.target.value)} value={details} className="form-control" maxlength="300" cols="30" rows="10" />
                    </div>
                    <div className="form-group" style={{ marginTop: 20, marginBottom: 20 }}>
                        <button style={{ marginLeft: 80 }} onClick={onSave} className="btn btn-success">Save</button>
                        <Link style={{ marginLeft: 40 }} to={"/my-blog"} className="btn btn-warning">
                            Cancel
                        </Link>
                    </div>

                </div>
                <div className="col"></div>
            </div>
        </div>
    )
}
export default EditBlog;