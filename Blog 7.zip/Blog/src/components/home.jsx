import { createURL } from "../config";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useEffect, useState } from "react";
 
const Home = () => {
  const navigate = useNavigate();
  const [searchitem, setSearch] =useState("");
  const [items, setItems] = useState("");
  const loadBlogs = () => {
    const url = createURL(`bytitle?FilterQuery=${searchitem}`);
 
    const token = sessionStorage["token"];
    if (!token) {
      navigate("/");
      return;
    }
    axios
      .get(url, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      .then((response) => {
        const result = response;
        if (result.status === 200) {
          const data = result.data;
          setItems(data);
        } else {
          alert("error while loading your blogs");
          navigate("/");
        }
       
      })  
         .catch((error) => {
        console.log(`error: `, error);
      });
  };
 
  useEffect(() => {
    loadBlogs();
  }, [items]);
  return (
    <div>
       <div id="search" style={{display:"flex", justifyContent:"center"}} >
       <form>
       <ul>
      <h2
        style={{ position: "relative", alignItems: "center",fontFamily: 'Times New Roman' }}
        className="title"
      >
        Blogs{" "}
      
       <input style={{marginTop:20,borderRadius:26,padding:"5px 50px 3px 10px",fontSize:"large"}}
        type="text"
        placeholder="Search..."
        onChange={(e) => setSearch(e.target.value)}
      />
      </h2>
      {/* <button onClick={loadBlogs} className="btn btn-primary">Search</button> */}
      </ul>
    </form>
    </div>
      <div>
        {items &&
          items.map((item, index) => {
            return (
              <div key={index} className="container-blog">
                <div className="fw-bold">Title: {item.title}</div>
                    <p >{item.details}</p>
                    <footer className="blockquote-footer m-2">
                      Posted on {item.createdDate}
                    </footer>
                {/* <p
                  style={{
                    marginLeft: 70,
                    marginTop: 10,
                    display: "flex",
                    alignItems: "center",
                    marginBottom: 10,
                  }}
                ></p> */}
              </div>
            );
          })}
      </div>
    </div>
  );
};
export default Home;

