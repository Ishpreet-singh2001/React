import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { createURL } from "../config";
import { toast } from "react-toastify";
import logo from "../image/noteimg.png";
import newlogin from "../image/Login img.jpg"
function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const onLogin = () => {
    if (email.length === 0) {
      toast.warn("please enter email");
    } else if (password.length === 0) {
      toast.warn("please enter password");
    } else {
      const url = createURL(`api/Users/login/${email}/${password}`);
      axios.post(url, { email, password }).then((response) => {
        if (response.status === 200) {
          sessionStorage["token"] = response.data;
          navigate("/home");
        } else {
          toast.error("Invalid email or password");
        }
      });
    }
    navigate("/home");
  };
  
  const onRegister = () => {
    console.log("register");
    navigate("/register");
  };
  
  return (
    <div style={{backgroundColor:"white",marginRight:-34,marginLeft:-34,marginBottom:-500}}>
      <div className="row">
        <div className="col">
          <img style={{objectFit:"cover",objectPosition:"center",borderRadius:"50%",marginTop: 100}} src={newlogin}  className="object-fit-contain" width="600" height="350" alt="blogimg image" />            
        </div>
        <div
          className="col"
          style={{
            boxShadow: "10px 10px 5px lightgrey",
            border: "1px solid Darkblue",
            marginTop: 80,
            borderRadius: 10,
            marginLeft:-100,
            marginRight:-100
            
          }}
        >
        <img style={{objectFit:"cover",objectPosition:"center",borderRadius:"50%",marginTop: 8}} src={logo}  className="rounded mx-auto d-block" width="75" height="75" alt="blogimg image" />            
          <h2 className="title" style={{fontFamily:"Times New Roman"}}>Login</h2>
          <div className="form-group">
            <label htmlFor="">Username:</label>
            <input
              onChange={(e) => setEmail(e.target.value)}
              type="text"
              className="form-control"
            />
          </div>
          <div className="form-group">
            <label htmlFor="">Password:</label>
            <input
              onChange={(e) => setPassword(e.target.value)}
              type="password"
              className="form-control"
            />
          </div>
          <div className="form-group mb-5">
            <button
              onClick={onLogin}
              className="btn btn-success"
              style={{ marginLeft:90, marginTop: 40 }}
            >
              Login
            </button>
            <button
              onClick={onRegister}
              className="btn btn-primary"
              style={{ marginLeft: 30, marginTop: 40 }}
            >
              Register
            </button>
          </div>
        </div>
        <div className="col"></div>
      </div>
    </div>
  );
}
export default Login;


