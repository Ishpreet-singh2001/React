import { createURL } from "../config"
import { useNavigate, useParams } from "react-router-dom"
import axios from 'axios'
import { useEffect, useState } from "react"
import { Link } from "react-router-dom";
import { BsHeart, BsShareFill } from "react-icons/bs";
import { FcLikePlaceholder } from "react-icons/fc";
import { AiFillEdit,AiOutlineLike, AiOutlineDelete } from "react-icons/ai";
import { toast } from "react-toastify";
const Myblog = () => {
    const navigate = useNavigate()
    const [items, setItems] = useState("");
    const token = sessionStorage["token"];
    const { id } = useParams();
    const onDelete = (id) => {
        const url = createURL(`api/Blogs/${id}`);
        if (!token) {
            navigate("/");
            return;
        }
        axios.delete(url, {
            headers: {
                "Authorization": `Bearer ${token}`,
            },
            id,
        })
            .then((response) => {
                const result = response.data;
                if (response.status) {
                    toast.success("Blog successfully deleted.")
                    loadBlogs();
                } else {
                    toast.error("error while deleting your blog");
                }
            })
            .catch((error) => {
                console.log(`error: `, error)
            });
    }
    const loadBlogs = () => {
        const url = createURL("api/Blogs/getmypost");
        if (!token) {
            navigate("/");
            return;
        }
        axios.get(url, {
            headers: {
                "Authorization": `Bearer ${token}`,
            },
        })
            .then((response) => {
                const result = response.data;
                if (response.status==200) {                    
                    setItems(result);                   
                } else {
                    alert("error while loading your blogs");
                    // navigate("/")
                }
            })
            .catch((error) => {
                console.log(`error: `, error)
            });
    };
    useEffect(() => {
        loadBlogs();
    }, []);
    return <div >
        <h2 style={{ position: "relative", alignItems: "center", fontFamily: 'Times New Roman'}} className="title">My Blog <Link style={{ marginTop: 8,marginRight:40,borderRadius:18 }} className="btn btn-dark btn-sm float-end" to="/new-blog">Add New Blog</Link></h2>
        <div>
            {items && items.map((item, index) => {
                return <div key={index} className="container-blog">
                    <div className="fw-bold">Title: {item.title}</div>
                    <div> <strong> Content:</strong> {item.details}</div>
                    <div style={{ position: "relative", marginLeft: 120, marginTop: 12 }}>
                        <Link to={`/my-blog/edit-blog/${item.idblog}`} style={{ textDecoration: "none", color: "black" }}><AiFillEdit style={{ fontSize: 30, marginRight: 30, cursor: "pointer" }} /></Link>
                        <AiOutlineDelete onClick={() => onDelete(item.idblog)} style={{ fontSize: 30, marginRight: 30, cursor: "pointer" }} />
                    </div>
                </div>
            })}
        </div>
    </div>
}
export default Myblog;