import { useState } from "react"
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { createURL } from '../config';
import axios from 'axios';
import { toast } from "react-toastify";
import Blogimg from "../image/noteimg.png";
import regimg from "../image/register.jpg";

function Register() {
    const navigate = useNavigate()
    const [fname, setFname] = useState("");
    const [lname, setLname] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [phone, setPhone] = useState("");
    const onRegister = () => {
        if (fname.length === 0) {
            toast.warn("please enter First Name")
        } else if (lname.length === 0) {
            toast.warn("please enter Last Name");
        } else if (email.length === 0 || !email.endsWith("@gmail.com")) {
            toast.warn("please enter proper Email");
        } else if (phone.length !== 10) {
            toast.warn("please enter 10 digit phone number");
        } else if (password.length < 8) {
            toast.warn("please should be more than 8 character password");
        } else if (password !== confirmPassword) {
            toast.warn("password does not match");
        }
        else {
            const data={
                firstName:fname,
                lastName:lname,
                email:email,
                password:password,
                confirmPassword:confirmPassword,
                phone:phone,
                UserType:"User"
            }
            const url = createURL("api/Users");
            axios.post(url,data)
                .then((response) => {
                    
                    if (response.status===201) {
                        toast.success("Register successfully")
                        navigate('/')
                    } 
                    else
                     {
                        toast.error("error while register");
                    }
                })
                .catch(e => {
                    toast.error(e.response.data)
                })
        }
    }
    return (
        <div style={{backgroundColor:"white",marginRight:-25,marginLeft:-25,marginBottom:-50}}>
            <div className="row">
            <div className="col">
        <img style={{objectFit:"cover",objectPosition:"center",borderRadius:"50%",marginTop: 160}} src={regimg}  className="object-fit-contain" width="650" height="350" alt="blogimg image" />            
        </div>
                <div className="col" style={{ boxShadow: "10px 10px 5px lightgrey", border: "1px solid darkblue", marginTop: 30, borderRadius: 10,marginLeft:-100, marginRight:-180 }}>
                <img style={{objectFit:"cover",objectPosition:"center",borderRadius:"50%",marginTop: 8}} src={Blogimg}  className="rounded mx-auto d-block" width="75" height="75" alt="blogimg image" />
                    <h2 className="title"style={{fontFamily:"Times New Roman"}}>Register</h2>
                    <div className="form-group">
                        <label htmlFor="">First Name:</label>
                        <input onChange={(e) => setFname(e.target.value)} type="text" className="form-control" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">Last Name:</label>
                        <input onChange={(e) => setLname(e.target.value)} type="text" className="form-control" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">Email:</label>
                        <input onChange={(e) => setEmail(e.target.value)} type="email" className="form-control" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">Mobile Number:</label>
                        <input onChange={(e) => setPhone(e.target.value)} type="number" className="form-control" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">Password:</label>
                        <input onChange={(e) => setPassword(e.target.value)} type="password" className="form-control" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">Confirm Password</label>
                        <input onChange={(e) => setConfirmPassword(e.target.value)} type="password" className="form-control" />
                    </div>
                    <button style={{ marginTop: 30, marginLeft: 90,marginBottom:-25}} onClick={onRegister} className="btn btn-success mb-5">Register</button>
                    <Link style={{ marginLeft: 15, marginTop: 30,marginBottom:-25 }} to={"/"} className="btn btn-primary mb-5">
                        Cancel
                    </Link>
                </div>
                <div className="col"></div>
            </div>
        </div>
    )
}
export default Register