export const SERVER = "https://localhost:7289";

export function createURL(path) {
  return `${SERVER}/${path}`;
}
