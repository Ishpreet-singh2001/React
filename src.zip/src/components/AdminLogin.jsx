
import React,{useEffect,useState} from "react";
import { Link ,useNavigate} from "react-router-dom";
//import { Footer, Navbar } from "../components";
import { toast, ToastContainer } from "react-toastify";
import axios from 'axios';
import 'react-toastify/dist/ReactToastify.css';
//import { baseUrl } from "./constant";
import  {createURL} from "./createURL";
 
function AdminLogin() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const navigate = useNavigate()
  const onLogin = () => {
      if (email.length === 0) {
          toast.warn("please enter email")
          alert("please enter email");
      } else if (password.length === 0) {
          toast.warn("please enter password");
          alert("please enter password");
      } else {
          const url = createURL(`api/Admins/login?email=${email}&password=${password}`);
          // const data={
          //   email:email,
          //   password:password
          // }
          axios.post(url)
              .then((response) => {
                 console.log(response);
                  if (response.status ==200) {
                  
                        sessionStorage["token"] = response.data;
                        alert("Login Successfully");
                        navigate("/AdminHome");
                       
                   
                  }else{
                    alert("Please Use Correct Email and Password");
                      toast.error("Invalid email or password");
                  }
              })
              .catch((error) => {
                console.error("An error occurred:", error);
                toast.error("An error occurred while logging in");
              });
      }
  }
  const onRegister = () => {
      console.log("register")
      navigate('/register')
  }
 
//  function Login() {
//   const [email, emailupdate] = useState("");
//   const [password, passwordupdate] = useState("");
 
  // const handleLogin = (e) => {
   
  //   let error = '';
  //   if(email === '')
  //   error = error + 'Email ,';
 
  //   if(password === '')
  //   error = error + 'Password ';
   
  //   if(error.length > 0)
  //   {
  //     error = error + ' can not be blank';
  //     alert(error);
  //     return;
  //   }
 
  //   e.preventDefault();
  //   const data = {
  //     Email: email,
  //     Password: password,
  //   };
  //  const url = `${baseUrl}/api/User/login?email=${data.Email}&password=${data.Password}`;
  //   axios
  //     .post(url)
  //     .then((result) => {
  //       console.log(result);
       
  //       if (result.status==200) {
         
  //         if (email === "admin@gmail.com" && password === "admin@gmail.com") {
  //           localStorage.setItem("username", email);
  //           window.location.href = "/admindashboard";
  //         } else {
  //           localStorage.setItem("username", email);
  //           //localStorage.setItem("username", dt.registration.name);
  //           window.location.href = "/CustomerList";
  //         }
  //       }
     
       
       
  //     });
      // .catch((error) => {
      //   console.log(error);
      // });
 
 
 
  return (
    <>
      {/* <Navbar /> */}
     
 <div>
       
 
            <div className="row">
                <div className="col"></div>
                <div className="col" style={{boxShadow:"10px 10px 5px lightblue",border:"1px solid blue",marginTop:150,borderRadius:10}}>
                <h2 className="title">Login</h2>
                    <div className="form-group">
                        <label htmlFor="">Email:</label>
                        <input onChange={(e) => setEmail(e.target.value)} type="text" className="form-control" />
                    </div>
                    <div className="form-group">
                        <label htmlFor="">Password:</label>
                        <input onChange={(e) => setPassword(e.target.value)} type="password" className="form-control" />
                    </div>
                    <div className="form-group mb-5" >
                        <button onClick={onLogin} className="btn btn-success" style={{ marginLeft: 100, marginTop: 40 }} >Login</button>
                        <button onClick={onRegister} className="btn btn-primary" style={{marginLeft:20,marginTop: 40 }}>Register</button>
                    </div>
                </div>
                <div className="col"></div>
            </div>
 
        </div>
      {/* <Footer /> */}
    </>
  );
};
 
 
export default AdminLogin;
 