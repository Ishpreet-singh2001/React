import './App.css';
// import AdminHome from './components/AdminHome';
import HomeRout from './components/HomeRout';

function App() {
  return (
    <div className="App">
          <HomeRout></HomeRout>
    </div>
  );
}

export default App;
